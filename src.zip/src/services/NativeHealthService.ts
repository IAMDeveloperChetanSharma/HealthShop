import { Platform } from 'react-native';
import { HealthReading } from '../types/models';
import { listReadings } from '../storage/localDb';

let nativeModule: any = null;
let isNativeAvailable = false;

// Try to load native module, fall back to local DB/mock if not available
try {
  const NativeHealth = require('../../modules/native-health/src/NativeHealth');
  nativeModule = NativeHealth;
  isNativeAvailable = true;
} catch (error) {
  console.warn('Native health module not available, using saved local data:', error);
  isNativeAvailable = false;
}

export async function requestHealthPermissions() {
  if (isNativeAvailable && nativeModule?.requestPermissions) {
    return nativeModule.requestPermissions();
  }
  return true;
}

export async function readLatestHealth(): Promise<HealthReading | null> {
  if (isNativeAvailable && nativeModule?.readLatest) {
    return nativeModule.readLatest();
  }

  const rows = await listReadings(1);
  return rows[0] ?? null;
}

export async function readHealthHistory(days = 7): Promise<HealthReading[]> {
  if (isNativeAvailable && nativeModule?.readHistory) {
    return nativeModule.readHistory(days);
  }

  return listReadings(200);
}

export const healthPlatform = Platform.OS;
